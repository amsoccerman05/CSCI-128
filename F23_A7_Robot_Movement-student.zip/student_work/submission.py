# Your name here
# CSCI 128 - Section ?
# Assessment 7
# References:
# Time:

def location_decision(battery_level, heat, sensor_reading, current_location, button_state):
    # algorithm 1 in the writeup
    pass  # pass is a placeholder keyword that does nothing. This line should be deleted once code has been added to the function


def battery_level_change(old_battery_level, distance_traveled):
    # algorithm 2 in the writeup
    pass  # pass is a placeholder keyword that does nothing. This line should be deleted once code has been added to the function


def heat_change(old_heat, distance_traveled):
    # algorithm 3 in the writeup
    pass  # pass is a placeholder keyword that does nothing. This line should be deleted once code has been added to the function


if __name__ == "__main__":
    # any code not inside a function above should be put here inside of the if
    pass  # pass is a placeholder keyword that does nothing. This line should be deleted once code has been added to the branch
