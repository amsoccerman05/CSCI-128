class Material:
    def __init__(self, id):
        pass

    def setPrice(self, price):
        pass

    def getPrice(self):
        pass

    def setMaterialType(self, materialType):
        pass

    def getMaterialType(self):
        pass

    def setID(self, id):
        pass

    def getID(self):
        pass


class ConstructionSite:
    def __init__(self, name, city):
        pass

    def addMaterial(self, material):
        pass

    def findMaterial(self, id):
        pass

    def calculatePrice(self):
        pass

    def countMaterials(self):
        pass

    def __str__(self):
        pass


if __name__ == "__main__":
    pass
