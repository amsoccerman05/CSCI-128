# import the Python random module
import random

# get the seed value to be used
seed = input("SEED> ")
# set the random seed
random.seed(seed)

# get the number of months to simulate
months = int(input("MONTHS> "))

# get the interest rate
interest = float(input("INTEREST> "))

# ask for the desired invest method
method = input("METHOD> ")

if method == "1":
    # savings account
    
elif method == "2":
    # index fund
    
elif method == "3":
    # roulette
    
